' =============================================================================
' COMFER_Buscador.vbs
' Ruta: C:\Users\USUARIO\Desktop\COMFER\COMFER_Buscador.vbs
'
' Uso: Doble clic en el archivo, o llamado desde Archicad via comando shell
' Abre V1_Construmaster.xlsm y lanza el buscador de materiales (UserForm1)
' =============================================================================

Dim xlApp
Dim xlBook
Dim xlPath

xlPath = "C:\Users\USUARIO\Desktop\COMFER\V1_Construmaster.xlsm"

' Verificar que el archivo existe
Dim fso
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FileExists(xlPath) Then
    MsgBox "No se encontró el archivo:" & vbCrLf & xlPath & vbCrLf & vbCrLf & _
           "Verifica la ruta en COMFER_Buscador.vbs", _
           vbExclamation, "COMFER"
    WScript.Quit
End If

' Intentar conectar con Excel si ya está abierto
On Error Resume Next
Set xlApp = GetObject(, "Excel.Application")
On Error GoTo 0

' Si Excel no está abierto, abrirlo
If IsNull(xlApp) Or IsEmpty(xlApp) Then
    Set xlApp = CreateObject("Excel.Application")
    xlApp.Visible = True
End If

' Verificar si el libro ya está abierto
Dim libroAbierto
libroAbierto = False
Dim wb
For Each wb In xlApp.Workbooks
    If InStr(LCase(wb.FullName), LCase("V1_Construmaster")) > 0 Then
        Set xlBook = wb
        libroAbierto = True
        Exit For
    End If
Next

' Si no está abierto, abrirlo
If Not libroAbierto Then
    Set xlBook = xlApp.Workbooks.Open(xlPath, , False)
End If

' Traer Excel al frente
xlApp.Visible = True
xlApp.WindowState = -4137  ' xlMaximized
xlBook.Activate

' Ejecutar la macro que abre el buscador
On Error Resume Next
xlApp.Run "'" & xlBook.Name & "'!BuscarMaterial"
If Err.Number <> 0 Then
    MsgBox "Error al abrir el buscador: " & Err.Description & vbCrLf & vbCrLf & _
           "Verifica que la macro 'BuscarMaterial' existe en Módulo1.", _
           vbExclamation, "COMFER"
End If
On Error GoTo 0
