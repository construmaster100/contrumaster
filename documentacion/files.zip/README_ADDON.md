# COMFER Add-On — Guía de Instalación y Uso
## Ruta: C:\Users\USUARIO\Desktop\COMFER\documentacion\

---

## ARQUITECTURA COMPLETA

```
ARCHICAD 22
  │  Usuario selecciona un elemento
  │  Menú: Extras → COMFER: Asignar Material...
  ▼
COMFER.apx  (Add-On C++)
  │  Obtiene GUID + tipo del elemento
  │  Named Pipe → COMFER_ToVBNet
  ▼
COMFER_Buscador.exe  (VB.NET Windows Forms)
  │  Lee materiales.json
  │  Muestra TextBox buscador + ListBox
  │  Usuario selecciona material
  │  Named Pipe → COMFER_FromVBNet
  ▼
COMFER.apx  (recibe JSON con el material)
  │  SetProperties → COMFER_Material, COMFER_Codigo, etc.
  ▼
Schedule de Archicad se actualiza automáticamente
```

---

## ESTRUCTURA DE ARCHIVOS

```
C:\Users\USUARIO\Desktop\COMFER\documentacion\
├── addon_cpp\
│   ├── COMFER_Addon.cpp       ← Código fuente del Add-On
│   ├── COMFER_Addon.rc        ← Recursos (menú, strings)
│   ├── CMakeLists.txt         ← Proyecto CMake
│   └── build\                 ← Generado por CMake
│       └── Release\
│           └── COMFER.apx     ← Add-On compilado
├── vbnet_app\
│   └── Form1.vb               ← Aplicación VB.NET buscador
└── data\
    └── materiales.json        ← Base de datos de materiales
```

---

## PASO 1 — Preparar el DevKit de Archicad 22

1. Crear cuenta en **https://archicadapi.graphisoft.com**
2. Descargar **Archicad 22 API DevKit for Windows**
3. Extraer en: `C:\ArchiCAD_API_DevKit_22\`
4. Verificar que exista: `C:\ArchiCAD_API_DevKit_22\Support\Inc\ACAPinc.h`

---

## PASO 2 — Compilar el Add-On C++

### Requisitos
- Visual Studio 2019 o 2022 (con workload "Desktop development with C++")
- CMake 3.16+ (incluido en Visual Studio o desde cmake.org)

### Compilación

Abrir **Developer Command Prompt for VS 2022** y ejecutar:

```batch
cd C:\Users\USUARIO\Desktop\COMFER\documentacion\addon_cpp
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

> Para Visual Studio 2019 usar: `-G "Visual Studio 16 2019"`

### Instalar el Add-On en Archicad

```batch
copy Release\COMFER.apx "C:\Program Files\GRAPHISOFT\ARCHICAD 22\Add-Ons\"
```

O usando cmake install:
```batch
cmake --install . --config Release
```

---

## PASO 3 — Crear la aplicación VB.NET

1. Abrir **Visual Studio**
2. **Archivo → Nuevo → Proyecto**
3. Seleccionar: **Windows Forms App (.NET Framework)**
4. Nombre: `COMFER_Buscador`
5. Framework: `.NET Framework 4.8`
6. Reemplazar el contenido de `Form1.vb` con el archivo proporcionado
7. Agregar referencia a **System.Web.Extensions**:
   - Click derecho en proyecto → Agregar referencia
   - Buscar: `System.Web.Extensions` → Agregar
8. **Compilar → Generar solución** (`Ctrl+Shift+B`)
9. El ejecutable queda en: `bin\Release\COMFER_Buscador.exe`

---

## PASO 4 — Configurar las Custom Properties en Archicad

El Add-On escribe en estas propiedades. **Debes crearlas previamente** en Archicad:

1. Archicad → **Opciones → Propiedades de elemento**
2. Crear grupo: `COMFER`
3. Agregar las siguientes propiedades (tipo: **Texto**):

| Nombre propiedad    | Tipo  | Descripción                    |
|---------------------|-------|--------------------------------|
| `COMFER_Material`   | Texto | Nombre del material asignado   |
| `COMFER_Codigo`     | Texto | Código del material            |
| `COMFER_Resistencia`| Texto | Resistencia / especificación   |
| `COMFER_Unidad`     | Texto | Unidad de medida               |
| `COMFER_Proveedor`  | Texto | Proveedor del material         |
| `COMFER_Descripcion`| Texto | Descripción completa           |

4. Agregar estas propiedades al **Schedule** deseado

---

## PASO 5 — Uso diario

### Orden de arranque (importante)
```
1. Abrir COMFER_Buscador.exe  ← PRIMERO (debe estar escuchando el pipe)
2. Abrir Archicad 22
3. Abrir el proyecto .pln
```

### Flujo de trabajo
```
1. En Archicad: seleccionar UN elemento (muro, losa, viga, etc.)
2. Menú: Extras → COMFER: Asignar Material al Elemento...
3. La app COMFER_Buscador se activa automáticamente
4. Escribir en el buscador (nombre, código, proveedor)
5. Seleccionar el material de la lista
6. Ver el detalle en el panel inferior
7. Clic "✔ Asignar a Archicad"
8. Las propiedades del elemento se actualizan
9. El Schedule refleja los cambios inmediatamente
```

---

## NAMED PIPES — Referencia técnica

| Pipe              | Dirección     | Servidor | Cliente |
|-------------------|---------------|----------|---------|
| `COMFER_ToVBNet`  | C++ → VB.NET  | VB.NET   | C++     |
| `COMFER_FromVBNet`| VB.NET → C++  | C++      | VB.NET  |

### Formato del mensaje C++ → VB.NET
```json
{"guid":"A1B2C3D4-...","tipo":"Muro"}
```

### Formato de respuesta VB.NET → C++
```json
{
  "nombre":      "Concreto 210 kg/cm²",
  "resistencia": "210 kg/cm²",
  "unidad":      "m³",
  "proveedor":   "ARGOS Colombia",
  "codigo":      "CON-210",
  "descripcion": "Concreto estructural de uso general"
}
```

---

## AGREGAR MATERIALES A LA BASE DE DATOS

Editar `C:\Users\USUARIO\Desktop\COMFER\documentacion\data\materiales.json`:

```json
{
  "codigo":      "MI-CODIGO",
  "nombre":      "Nombre del material",
  "categoria":   "Concreto / Acero / Mampostería / ...",
  "resistencia": "valor técnico",
  "unidad":      "m² / m³ / kg / ml",
  "proveedor":   "Nombre del proveedor",
  "precio":      "$ 000.000 / unidad",
  "descripcion": "Descripción técnica completa"
}
```

La app VB.NET carga el JSON cada vez que se inicia. Para recargar sin reiniciar, agrega un botón "Recargar BD" que llame a `CargarMateriales()`.

---

## SOLUCIÓN DE PROBLEMAS

| Problema | Causa | Solución |
|----------|-------|----------|
| "No se pudo conectar con COMFER_Buscador" | La app VB.NET no está abierta | Iniciar COMFER_Buscador.exe antes de Archicad |
| Add-On no aparece en Extras | .apx no está en la carpeta Add-Ons | Verificar ruta de instalación |
| Propiedades no se escriben | Properties no creadas en Archicad | Crear las 6 properties COMFER_* manualmente |
| Error de compilación CMake | DevKit no encontrado | Verificar ruta AC_API_DEVKIT_DIR |
| "System.Web.Extensions not found" | Referencia faltante en VB.NET | Agregar referencia en el proyecto VS |

---

## COMPILACIÓN RÁPIDA (resumen)

```batch
REM 1. Compilar Add-On
cd C:\Users\USUARIO\Desktop\COMFER\documentacion\addon_cpp
mkdir build & cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
copy Release\COMFER.apx "C:\Program Files\GRAPHISOFT\ARCHICAD 22\Add-Ons\"

REM 2. Compilar VB.NET (desde Developer Command Prompt)
cd C:\Users\USUARIO\Desktop\COMFER\documentacion\vbnet_app\COMFER_Buscador
msbuild COMFER_Buscador.sln /p:Configuration=Release
```
