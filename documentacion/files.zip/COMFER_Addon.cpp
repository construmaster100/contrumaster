// =============================================================================
// COMFER Add-On para Archicad 22
// Archivo: COMFER_Addon.cpp
// Ruta destino: C:\Users\USUARIO\Desktop\COMFER\documentacion\addon_cpp\
//
// Flujo:
//   1. Usuario selecciona un elemento en Archicad
//   2. Menú / paleta dispara el comando
//   3. Add-On obtiene el GUID del elemento seleccionado
//   4. Envía GUID a la app VB.NET vía Named Pipe
//   5. VB.NET muestra el buscador, usuario elige material
//   6. App devuelve las propiedades por Named Pipe
//   7. Add-On escribe las UserDefined Properties en el elemento
//   8. Schedule se actualiza automáticamente
//
// Requisitos:
//   - Archicad 22 API DevKit (de Graphisoft Developer Portal)
//   - Visual Studio 2019 o 2022
//   - CMake 3.16+
// =============================================================================

#include "ACAPinc.h"          // API principal de Archicad
#include "APIEnvir.h"
#include "API_Guid.hpp"

#include <windows.h>
#include <string>
#include <sstream>
#include <vector>
#include <thread>
#include <stdexcept>

// ─── CONSTANTES ──────────────────────────────────────────────────────────────
static const char* PIPE_NAME_OUT = "\\\\.\\pipe\\COMFER_ToVBNet";   // C++ → VB.NET
static const char* PIPE_NAME_IN  = "\\\\.\\pipe\\COMFER_FromVBNet"; // VB.NET → C++
static const DWORD PIPE_TIMEOUT  = 10000;  // 10 segundos
static const Int32 MENU_CMD_ID   = 1;      // ID del comando de menú

// ─── FORWARD DECLARATIONS ────────────────────────────────────────────────────
static GSErrCode   OnMenuCommand(const API_MenuParams* menuParams);
static std::string GuidToString(const API_Guid& guid);
static API_Guid    StringToGuid(const std::string& str);
static bool        SendToPipe(const std::string& pipeName, const std::string& data);
static std::string ReceiveFromPipe(const std::string& pipeName);
static GSErrCode   WriteUserProperties(const API_Guid& elemGuid,
                                       const std::string& jsonProps);

// =============================================================================
// PUNTO DE ENTRADA DEL ADD-ON
// =============================================================================
API_AddonType __ACDL_CALL CheckEnvironment(API_EnvirParams* envir)
{
    RSGetIndString(&envir->addOnInfo.name,        32500, 1, ACAPI_GetOwnResModule());
    RSGetIndString(&envir->addOnInfo.description, 32500, 2, ACAPI_GetOwnResModule());
    return APIAddon_Normal;
}

GSErrCode __ACDL_CALL RegisterInterface()
{
    // Registrar comando de menú en "Extras"
    return ACAPI_MenuItem_RegisterMenu(32500, 32600, MenuCode_UserDef, MenuFlag_Default);
}

GSErrCode __ACDL_CALL Initialize()
{
    // Vincular el handler del menú
    GSErrCode err = ACAPI_MenuItem_InstallMenuHandler(32500, OnMenuCommand);
    if (err != NoError)
        ACAPI_WriteReport("COMFER: Error al registrar menú handler", false);

    return err;
}

GSErrCode __ACDL_CALL FreeData()
{
    return NoError;
}

// =============================================================================
// HANDLER DEL COMANDO DE MENÚ
// Se ejecuta cuando el usuario hace clic en Extras → COMFER: Asignar Material
// =============================================================================
static GSErrCode OnMenuCommand(const API_MenuParams* /*menuParams*/)
{
    // ── 1. Verificar que hay exactamente un elemento seleccionado ──────────
    API_SelectionInfo selInfo = {};
    GS::Array<API_Neig> selNeigs;

    GSErrCode err = ACAPI_Selection_Get(&selInfo, &selNeigs, true);
    if (err != NoError || selInfo.typeID == API_SelEmpty) {
        ACAPI_WriteReport("COMFER: Seleccione un elemento antes de usar esta función.", true);
        return NoError;
    }

    if (selNeigs.GetSize() != 1) {
        ACAPI_WriteReport("COMFER: Seleccione exactamente un elemento.", true);
        return NoError;
    }

    // ── 2. Obtener el GUID del elemento seleccionado ───────────────────────
    API_Guid elemGuid = selNeigs[0].guid;
    std::string guidStr = GuidToString(elemGuid);

    // ── 3. Obtener tipo de elemento para contexto ──────────────────────────
    API_Element elem = {};
    elem.header.guid = elemGuid;
    err = ACAPI_Element_Get(&elem);
    if (err != NoError) {
        ACAPI_WriteReport("COMFER: No se pudo obtener el elemento.", true);
        return err;
    }

    std::string elemType;
    switch (elem.header.typeID) {
        case API_WallID:    elemType = "Muro";     break;
        case API_SlabID:    elemType = "Losa";     break;
        case API_BeamID:    elemType = "Viga";     break;
        case API_ColumnID:  elemType = "Columna";  break;
        case API_WindowID:  elemType = "Ventana";  break;
        case API_DoorID:    elemType = "Puerta";   break;
        case API_RoofID:    elemType = "Cubierta"; break;
        default:            elemType = "Elemento"; break;
    }

    // ── 4. Construir mensaje JSON para VB.NET ──────────────────────────────
    // Formato: {"guid":"...","tipo":"..."}
    std::ostringstream msg;
    msg << "{\"guid\":\"" << guidStr << "\","
        << "\"tipo\":\"" << elemType << "\"}";

    ACAPI_WriteReport(("COMFER: Enviando a buscador → " + guidStr).c_str(), false);

    // ── 5. Enviar a VB.NET por Named Pipe ─────────────────────────────────
    if (!SendToPipe(PIPE_NAME_OUT, msg.str())) {
        ACAPI_WriteReport(
            "COMFER: No se pudo conectar con la app COMFER_Buscador.\n"
            "Asegúrese de que COMFER_Buscador.exe esté en ejecución.",
            true);
        return NoError;
    }

    // ── 6. Esperar respuesta de VB.NET (bloqueante con timeout) ───────────
    std::string response = ReceiveFromPipe(PIPE_NAME_IN);

    if (response.empty() || response == "CANCELADO") {
        ACAPI_WriteReport("COMFER: Operación cancelada por el usuario.", false);
        return NoError;
    }

    // ── 7. Escribir las propiedades en el elemento ─────────────────────────
    // response es JSON: {"nombre":"Concreto 210","resistencia":"210 kg/cm2",...}
    err = WriteUserProperties(elemGuid, response);
    if (err == NoError)
        ACAPI_WriteReport("COMFER: ✓ Material asignado correctamente.", false);
    else
        ACAPI_WriteReport("COMFER: Error al escribir propiedades en el elemento.", true);

    return NoError;
}

// =============================================================================
// ESCRITURA DE USERDEFINED PROPERTIES EN EL ELEMENTO
// =============================================================================
static GSErrCode WriteUserProperties(const API_Guid& elemGuid,
                                     const std::string& jsonProps)
{
    // Parseo manual del JSON simple recibido de VB.NET
    // Formato esperado:
    // {
    //   "nombre"       : "Concreto 210",
    //   "resistencia"  : "210 kg/cm2",
    //   "unidad"       : "m3",
    //   "proveedor"    : "ARGOS",
    //   "codigo"       : "CON-210",
    //   "descripcion"  : "Concreto de alta resistencia"
    // }

    auto extractValue = [&](const std::string& key) -> std::string {
        std::string search = "\"" + key + "\"";
        size_t pos = jsonProps.find(search);
        if (pos == std::string::npos) return "";
        pos = jsonProps.find(":", pos);
        if (pos == std::string::npos) return "";
        pos = jsonProps.find("\"", pos);
        if (pos == std::string::npos) return "";
        size_t end = jsonProps.find("\"", pos + 1);
        if (end == std::string::npos) return "";
        return jsonProps.substr(pos + 1, end - pos - 1);
    };

    // Mapa de nombre de property → valor
    struct PropAssign { std::string propName; std::string value; };
    std::vector<PropAssign> assignments = {
        { "COMFER_Material",     extractValue("nombre")      },
        { "COMFER_Resistencia",  extractValue("resistencia") },
        { "COMFER_Unidad",       extractValue("unidad")      },
        { "COMFER_Proveedor",    extractValue("proveedor")   },
        { "COMFER_Codigo",       extractValue("codigo")      },
        { "COMFER_Descripcion",  extractValue("descripcion") },
    };

    GSErrCode lastErr = NoError;

    for (const auto& pa : assignments) {
        if (pa.value.empty()) continue;

        // Buscar la property por nombre en el proyecto
        API_Property property = {};
        GS::UniString propName(pa.propName.c_str(), CC_UTF8);

        // Obtener todas las definiciones del elemento
        GS::Array<API_PropertyDefinition> defs;
        GSErrCode err = ACAPI_Element_GetPropertyDefinitions(
            elemGuid, API_PropertyDefinitionFilter_UserDefined, defs);

        if (err != NoError) continue;

        bool found = false;
        for (const auto& def : defs) {
            if (def.name == propName) {
                property.definition = def;
                found = true;
                break;
            }
        }
        if (!found) continue;

        // Asignar valor string
        property.isDefault = false;
        property.value.primitiveType = API_PropertyStringValueType;
        property.value.singleVariant.variant.uniStringValue =
            GS::UniString(pa.value.c_str(), CC_UTF8);
        property.value.singleVariant.variant.type = API_PropertyStringValueType;

        // Escribir en el elemento
        GS::Array<API_Property> props;
        props.Push(property);
        err = ACAPI_Element_SetProperties(elemGuid, props);
        if (err != NoError) lastErr = err;
    }

    return lastErr;
}

// =============================================================================
// NAMED PIPES — COMUNICACIÓN CON VB.NET
// =============================================================================

// Enviar datos al pipe (C++ es el cliente, VB.NET es el servidor del pipe OUT)
static bool SendToPipe(const std::string& pipeName, const std::string& data)
{
    HANDLE hPipe = CreateFileA(
        pipeName.c_str(),
        GENERIC_WRITE,
        0, nullptr,
        OPEN_EXISTING,
        0, nullptr);

    if (hPipe == INVALID_HANDLE_VALUE) {
        // Intentar una vez más después de breve espera
        Sleep(500);
        hPipe = CreateFileA(pipeName.c_str(), GENERIC_WRITE, 0,
                            nullptr, OPEN_EXISTING, 0, nullptr);
        if (hPipe == INVALID_HANDLE_VALUE) return false;
    }

    DWORD written = 0;
    BOOL ok = WriteFile(hPipe, data.c_str(),
                        static_cast<DWORD>(data.size()),
                        &written, nullptr);
    CloseHandle(hPipe);
    return ok && written == data.size();
}

// Recibir datos del pipe (C++ crea el servidor, VB.NET escribe la respuesta)
static std::string ReceiveFromPipe(const std::string& pipeName)
{
    HANDLE hPipe = CreateNamedPipeA(
        pipeName.c_str(),
        PIPE_ACCESS_INBOUND,
        PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
        1,          // max instancias
        4096,       // buffer salida
        4096,       // buffer entrada
        PIPE_TIMEOUT,
        nullptr);

    if (hPipe == INVALID_HANDLE_VALUE) return "";

    // Esperar conexión de VB.NET (bloqueante, con timeout implícito del pipe)
    BOOL connected = ConnectNamedPipe(hPipe, nullptr);
    if (!connected && GetLastError() != ERROR_PIPE_CONNECTED) {
        CloseHandle(hPipe);
        return "";
    }

    char buffer[8192] = {};
    DWORD bytesRead = 0;
    BOOL ok = ReadFile(hPipe, buffer, sizeof(buffer) - 1, &bytesRead, nullptr);
    CloseHandle(hPipe);

    if (!ok || bytesRead == 0) return "";
    return std::string(buffer, bytesRead);
}

// =============================================================================
// UTILIDADES DE GUID
// =============================================================================
static std::string GuidToString(const API_Guid& guid)
{
    char buf[64] = {};
    snprintf(buf, sizeof(buf),
        "%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X",
        guid.time_low,
        guid.time_mid,
        guid.time_hi_and_version,
        guid.clock_seq_hi_and_reserved,
        guid.clock_seq_low,
        guid.node[0], guid.node[1], guid.node[2],
        guid.node[3], guid.node[4], guid.node[5]);
    return std::string(buf);
}
