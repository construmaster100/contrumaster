' =============================================================================
' COMFER_Buscador — Aplicación VB.NET
' Archivo: Form1.vb
' Ruta: C:\Users\USUARIO\Desktop\COMFER\documentacion\vbnet_app\
'
' Proyecto: Windows Forms App (.NET Framework 4.8)
' Nombre ensamblado: COMFER_Buscador
'
' Crea un nuevo proyecto en Visual Studio:
'   Archivo → Nuevo → Proyecto → Windows Forms App (.NET Framework)
'   Nombre: COMFER_Buscador
'   Framework: .NET Framework 4.8
' Luego reemplaza Form1.vb con este código.
' =============================================================================

Imports System.IO
Imports System.IO.Pipes
Imports System.Text
Imports System.Threading
Imports System.Web.Script.Serialization   ' Agrega referencia: System.Web.Extensions

Public Class Form1

    ' ── Rutas ────────────────────────────────────────────────────────────────
    Private Const PIPE_IN  As String = "COMFER_ToVBNet"    ' Recibe de C++
    Private Const PIPE_OUT As String = "COMFER_FromVBNet"  ' Envía a C++
    Private Const JSON_PATH As String = _
        "C:\Users\USUARIO\Desktop\COMFER\documentacion\data\materiales.json"

    ' ── Estado ───────────────────────────────────────────────────────────────
    Private _materiales As List(Of Material)
    Private _elementoGuid As String = ""
    Private _elementoTipo As String = ""
    Private _pipeThread As Thread
    Private _esperandoRespuesta As Boolean = False

    ' ─────────────────────────────────────────────────────────────────────────
    ' INICIALIZACIÓN
    ' ─────────────────────────────────────────────────────────────────────────
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "COMFER — Buscador de Materiales"
        Me.Size = New Size(580, 520)
        Me.FormBorderStyle = FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.BackColor = Color.FromArgb(240, 245, 250)

        InicializarControles()
        CargarMateriales()
        IniciarServidorPipe()

        lblEstado.Text = "⏳ Esperando selección desde Archicad..."
        lblEstado.ForeColor = Color.DimGray
    End Sub

    ' ─────────────────────────────────────────────────────────────────────────
    ' CONTROLES UI
    ' ─────────────────────────────────────────────────────────────────────────
    Private WithEvents txtBuscar   As New TextBox()
    Private WithEvents lstMateriales As New ListBox()
    Private WithEvents btnAsignar  As New Button()
    Private WithEvents btnCancelar As New Button()
    Private WithEvents lblTitulo   As New Label()
    Private WithEvents lblElemento As New Label()
    Private WithEvents lblEstado   As New Label()
    Private WithEvents panelDetalle As New Panel()
    Private WithEvents lblDetalle  As New Label()

    Private Sub InicializarControles()
        ' ── Título ──
        lblTitulo.Text = "COMFER — Asignador de Materiales"
        lblTitulo.Font = New Font("Segoe UI", 13, FontStyle.Bold)
        lblTitulo.ForeColor = Color.FromArgb(13, 27, 42)
        lblTitulo.Location = New Point(16, 12)
        lblTitulo.Size = New Size(540, 28)

        ' ── Info elemento ──
        lblElemento.Text = "Elemento: (sin selección)"
        lblElemento.Font = New Font("Segoe UI", 9)
        lblElemento.ForeColor = Color.FromArgb(40, 128, 144)
        lblElemento.Location = New Point(16, 46)
        lblElemento.Size = New Size(540, 20)

        ' ── Buscador ──
        txtBuscar.PlaceholderText = "🔍  Buscar material por nombre, código o proveedor..."
        txtBuscar.Font = New Font("Segoe UI", 10)
        txtBuscar.Location = New Point(16, 75)
        txtBuscar.Size = New Size(540, 28)
        txtBuscar.BorderStyle = BorderStyle.FixedSingle

        ' ── Lista ──
        lstMateriales.Font = New Font("Segoe UI", 10)
        lstMateriales.Location = New Point(16, 112)
        lstMateriales.Size = New Size(540, 200)
        lstMateriales.BorderStyle = BorderStyle.FixedSingle
        lstMateriales.IntegralHeight = False

        ' ── Panel detalle ──
        panelDetalle.Location = New Point(16, 322)
        panelDetalle.Size = New Size(540, 90)
        panelDetalle.BackColor = Color.FromArgb(230, 245, 255)
        panelDetalle.BorderStyle = BorderStyle.FixedSingle

        lblDetalle.Text = "Selecciona un material para ver sus detalles"
        lblDetalle.Font = New Font("Segoe UI", 9)
        lblDetalle.ForeColor = Color.FromArgb(60, 80, 100)
        lblDetalle.Location = New Point(8, 6)
        lblDetalle.Size = New Size(524, 78)
        panelDetalle.Controls.Add(lblDetalle)

        ' ── Botones ──
        btnAsignar.Text = "✔  Asignar a Archicad"
        btnAsignar.Font = New Font("Segoe UI", 10, FontStyle.Bold)
        btnAsignar.BackColor = Color.FromArgb(2, 128, 144)
        btnAsignar.ForeColor = Color.White
        btnAsignar.FlatStyle = FlatStyle.Flat
        btnAsignar.FlatAppearance.BorderSize = 0
        btnAsignar.Location = New Point(16, 424)
        btnAsignar.Size = New Size(200, 36)
        btnAsignar.Enabled = False

        btnCancelar.Text = "✖  Cancelar"
        btnCancelar.Font = New Font("Segoe UI", 10)
        btnCancelar.BackColor = Color.FromArgb(220, 53, 69)
        btnCancelar.ForeColor = Color.White
        btnCancelar.FlatStyle = FlatStyle.Flat
        btnCancelar.FlatAppearance.BorderSize = 0
        btnCancelar.Location = New Point(228, 424)
        btnCancelar.Size = New Size(140, 36)

        ' ── Estado ──
        lblEstado.Font = New Font("Segoe UI", 8.5)
        lblEstado.Location = New Point(16, 468)
        lblEstado.Size = New Size(540, 20)

        ' ── Agregar controles al form ──
        Me.Controls.AddRange(New Control() {
            lblTitulo, lblElemento, txtBuscar,
            lstMateriales, panelDetalle,
            btnAsignar, btnCancelar, lblEstado
        })
    End Sub

    ' ─────────────────────────────────────────────────────────────────────────
    ' CARGA DE MATERIALES DESDE JSON
    ' ─────────────────────────────────────────────────────────────────────────
    Private Sub CargarMateriales()
        Try
            If Not File.Exists(JSON_PATH) Then
                lblEstado.Text = "⚠ No se encontró materiales.json en: " & JSON_PATH
                lblEstado.ForeColor = Color.OrangeRed
                _materiales = New List(Of Material)()
                Return
            End If

            Dim json As String = File.ReadAllText(JSON_PATH, Encoding.UTF8)
            Dim js As New JavaScriptSerializer()
            Dim root As Dictionary(Of String, Object) = js.Deserialize(Of Dictionary(Of String, Object))(json)
            Dim arr As ArrayList = CType(root("materiales"), ArrayList)

            _materiales = New List(Of Material)()
            For Each item As Dictionary(Of String, Object) In arr
                Dim m As New Material()
                m.Nombre      = CStr(If(item.ContainsKey("nombre"),      item("nombre"),      ""))
                m.Codigo      = CStr(If(item.ContainsKey("codigo"),      item("codigo"),      ""))
                m.Categoria   = CStr(If(item.ContainsKey("categoria"),   item("categoria"),   ""))
                m.Resistencia = CStr(If(item.ContainsKey("resistencia"), item("resistencia"), ""))
                m.Unidad      = CStr(If(item.ContainsKey("unidad"),      item("unidad"),      ""))
                m.Proveedor   = CStr(If(item.ContainsKey("proveedor"),   item("proveedor"),   ""))
                m.Descripcion = CStr(If(item.ContainsKey("descripcion"), item("descripcion"), ""))
                m.Precio      = CStr(If(item.ContainsKey("precio"),      item("precio"),      ""))
                _materiales.Add(m)
            Next

            FiltrarLista("")
            lblEstado.Text = $"✓ {_materiales.Count} materiales cargados desde base de datos."
            lblEstado.ForeColor = Color.SeaGreen

        Catch ex As Exception
            lblEstado.Text = "Error al cargar materiales: " & ex.Message
            lblEstado.ForeColor = Color.Red
            _materiales = New List(Of Material)()
        End Try
    End Sub

    Private Sub FiltrarLista(filtro As String)
        lstMateriales.Items.Clear()
        Dim lower = filtro.ToLower()
        For Each m As Material In _materiales
            If lower = "" OrElse
               m.Nombre.ToLower.Contains(lower) OrElse
               m.Codigo.ToLower.Contains(lower) OrElse
               m.Proveedor.ToLower.Contains(lower) OrElse
               m.Categoria.ToLower.Contains(lower) Then
                lstMateriales.Items.Add(m)
            End If
        Next
    End Sub

    ' ─────────────────────────────────────────────────────────────────────────
    ' EVENTOS DE UI
    ' ─────────────────────────────────────────────────────────────────────────
    Private Sub txtBuscar_TextChanged(sender As Object, e As EventArgs) _
        Handles txtBuscar.TextChanged
        FiltrarLista(txtBuscar.Text.Trim())
    End Sub

    Private Sub lstMateriales_SelectedIndexChanged(sender As Object, e As EventArgs) _
        Handles lstMateriales.SelectedIndexChanged
        If lstMateriales.SelectedItem Is Nothing Then
            btnAsignar.Enabled = False
            lblDetalle.Text = "Selecciona un material para ver sus detalles"
            Return
        End If

        Dim m As Material = CType(lstMateriales.SelectedItem, Material)
        lblDetalle.Text = $"Código: {m.Codigo}   |   Categoría: {m.Categoria}" & vbCrLf &
                          $"Resistencia: {m.Resistencia}   |   Unidad: {m.Unidad}   |   Precio: {m.Precio}" & vbCrLf &
                          $"Proveedor: {m.Proveedor}" & vbCrLf &
                          $"Descripción: {m.Descripcion}"
        btnAsignar.Enabled = _esperandoRespuesta
    End Sub

    Private Sub btnAsignar_Click(sender As Object, e As EventArgs) _
        Handles btnAsignar.Click
        If lstMateriales.SelectedItem Is Nothing Then Return

        Dim m As Material = CType(lstMateriales.SelectedItem, Material)
        Dim respuesta As String = m.ToJson()

        ' Enviar respuesta al Add-On C++ por Named Pipe
        Dim t As New Thread(Sub() EnviarRespuesta(respuesta))
        t.IsBackground = True
        t.Start()

        lblEstado.Text = $"✓ Enviando «{m.Nombre}» a Archicad..."
        lblEstado.ForeColor = Color.SeaGreen
        btnAsignar.Enabled = False
        _esperandoRespuesta = False
        lblElemento.Text = "Elemento: (sin selección)"
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) _
        Handles btnCancelar.Click
        Dim t As New Thread(Sub() EnviarRespuesta("CANCELADO"))
        t.IsBackground = True
        t.Start()
        _esperandoRespuesta = False
        btnAsignar.Enabled = False
        lblEstado.Text = "Operación cancelada."
        lblEstado.ForeColor = Color.DimGray
        lblElemento.Text = "Elemento: (sin selección)"
    End Sub

    ' ─────────────────────────────────────────────────────────────────────────
    ' NAMED PIPES — SERVIDOR (espera mensajes del Add-On C++)
    ' ─────────────────────────────────────────────────────────────────────────
    Private Sub IniciarServidorPipe()
        _pipeThread = New Thread(AddressOf EscucharPipe)
        _pipeThread.IsBackground = True
        _pipeThread.Start()
    End Sub

    Private Sub EscucharPipe()
        Do
            Try
                Using server As New NamedPipeServerStream(
                    PIPE_IN,
                    PipeDirection.In,
                    1,
                    PipeTransmissionMode.Message,
                    PipeOptions.None)

                    server.WaitForConnection()  ' Bloquea hasta que C++ conecta

                    Using reader As New StreamReader(server, Encoding.UTF8)
                        Dim msg As String = reader.ReadToEnd()
                        If Not String.IsNullOrEmpty(msg) Then
                            ProcesarMensajeDeArchicad(msg)
                        End If
                    End Using
                End Using

            Catch ex As Exception
                ' El form puede estar cerrándose
                Thread.Sleep(500)
            End Try
        Loop
    End Sub

    Private Sub ProcesarMensajeDeArchicad(msg As String)
        ' Parseo simple: {"guid":"...","tipo":"..."}
        Try
            Dim js As New JavaScriptSerializer()
            Dim data As Dictionary(Of String, Object) = js.Deserialize(Of Dictionary(Of String, Object))(msg)
            _elementoGuid = CStr(data("guid"))
            _elementoTipo = CStr(data("tipo"))
        Catch
            _elementoGuid = msg
            _elementoTipo = "Elemento"
        End Try

        ' Actualizar UI desde hilo principal
        Me.Invoke(Sub()
            lblElemento.Text = $"Elemento: {_elementoTipo}  |  GUID: {_elementoGuid}"
            lblEstado.Text = "✓ Elemento recibido. Selecciona un material y haz clic en Asignar."
            lblEstado.ForeColor = Color.FromArgb(2, 128, 144)
            _esperandoRespuesta = True
            If lstMateriales.SelectedItem IsNot Nothing Then
                btnAsignar.Enabled = True
            End If
            Me.BringToFront()
            Me.Activate()
        End Sub)
    End Sub

    Private Sub EnviarRespuesta(respuesta As String)
        Try
            Using client As New NamedPipeClientStream(
                ".", PIPE_OUT,
                PipeDirection.Out,
                PipeOptions.None)

                client.Connect(8000)  ' timeout 8 segundos
                Dim bytes() As Byte = Encoding.UTF8.GetBytes(respuesta)
                client.Write(bytes, 0, bytes.Length)
                client.Flush()
            End Using
        Catch ex As Exception
            Me.Invoke(Sub()
                lblEstado.Text = "Error al enviar respuesta a Archicad: " & ex.Message
                lblEstado.ForeColor = Color.Red
            End Sub)
        End Try
    End Sub

    ' ─────────────────────────────────────────────────────────────────────────
    ' CIERRE
    ' ─────────────────────────────────────────────────────────────────────────
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) _
        Handles MyBase.FormClosing
        If _pipeThread IsNot Nothing AndAlso _pipeThread.IsAlive Then
            _pipeThread.Abort()
        End If
    End Sub

End Class

' =============================================================================
' MODELO DE DATOS
' =============================================================================
Public Class Material
    Public Property Nombre      As String = ""
    Public Property Codigo      As String = ""
    Public Property Categoria   As String = ""
    Public Property Resistencia As String = ""
    Public Property Unidad      As String = ""
    Public Property Proveedor   As String = ""
    Public Property Descripcion As String = ""
    Public Property Precio      As String = ""

    ' Representación en lista
    Public Overrides Function ToString() As String
        Return $"[{Codigo}]  {Nombre}  —  {Categoria}"
    End Function

    ' JSON para enviar al Add-On C++
    Public Function ToJson() As String
        Return "{" &
            $"""nombre"":""{EscJson(Nombre)}""," &
            $"""resistencia"":""{EscJson(Resistencia)}""," &
            $"""unidad"":""{EscJson(Unidad)}""," &
            $"""proveedor"":""{EscJson(Proveedor)}""," &
            $"""codigo"":""{EscJson(Codigo)}""," &
            $"""descripcion"":""{EscJson(Descripcion)}""" &
            "}"
    End Function

    Private Function EscJson(s As String) As String
        Return s.Replace("\", "\\").Replace("""", "\""")
    End Function
End Class
